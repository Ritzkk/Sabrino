const perguntas = [
  { q: "Qual posição o LaMelo Ball joga?",
    o: ["Pivô", "Armador", "Ala-pivô", "Ala"], c: 1,
    e: "LaMelo é armador, conhecido pela visão de jogo e pelos passes." },
  { q: "Em qual posição ele foi escolhido no draft de 2020?",
    o: ["1ª", "2ª", "3ª", "5ª"], c: 2,
    e: "Foi a 3ª escolha do draft de 2020, pelo Charlotte Hornets." },
  { q: "Em qual time australiano ele jogou antes da NBA?",
    o: ["Sydney Kings", "Perth Wildcats", "Melbourne United", "Illawarra Hawks"], c: 3,
    e: "Ele defendeu o Illawarra Hawks na NBL em 2019-20 e foi o Rookie of the Year da liga." },
  { q: "Em que ano ele foi eleito Rookie of the Year da NBA?",
    o: ["2020", "2021", "2022", "2023"], c: 1,
    e: "O prêmio veio em 2021, na temporada de estreia." },
  { q: "Em que ano ele jogou o All-Star Game?",
    o: ["2021", "2022", "2024", "2025"], c: 1,
    e: "LaMelo foi All-Star em 2022, na segunda temporada." },
  { q: "Contra qual time ele marcou seus 50 pontos, recorde pessoal?",
    o: ["Milwaukee Bucks", "Boston Celtics", "Miami Heat", "New York Knicks"], c: 0,
    e: "Os 50 pontos foram contra o Milwaukee Bucks." },
  { q: "Para qual time ele foi trocado em junho de 2026?",
    o: ["Lakers", "Timberwolves", "Warriors", "Pistons"], c: 1,
    e: "Os Hornets o enviaram ao Minnesota Timberwolves em troca de Naz Reid e escolhas de draft." }
];

let atual = 0, pontos = 0, respondeu = false;

const elPergunta = document.getElementById("quiz_pergunta");
const elOpcoes = document.getElementById("quiz_opcoes");
const elFeedback = document.getElementById("quiz_feedback");
const elProgresso = document.getElementById("quiz_progresso");
const elPontos = document.getElementById("quiz_pontos");
const elBarra = document.getElementById("quiz_barra_cheia");
const btnProxima = document.getElementById("quiz_proxima");
const btnReiniciar = document.getElementById("quiz_reiniciar");

function mostrar() {
  const p = perguntas[atual];
  respondeu = false;
  elPergunta.textContent = p.q;
  elFeedback.textContent = "";
  elFeedback.className = "quiz_feedback";
  elProgresso.textContent = "Pergunta " + (atual + 1) + " de " + perguntas.length;
  elPontos.textContent = pontos + (pontos === 1 ? " ponto" : " pontos");
  elBarra.style.width = (atual / perguntas.length * 100) + "%";
  btnProxima.hidden = true;
  btnReiniciar.hidden = true;
  elOpcoes.innerHTML = "";

  p.o.forEach((texto, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "quiz_opcao";
    b.textContent = texto;
    b.addEventListener("click", () => responder(i));
    elOpcoes.appendChild(b);
  });
}

function responder(i) {
  if (respondeu) return;
  respondeu = true;
  const p = perguntas[atual];
  const botoes = elOpcoes.querySelectorAll(".quiz_opcao");
  botoes.forEach((b, idx) => {
    b.disabled = true;
    if (idx === p.c) b.classList.add("certa");
    else if (idx === i) b.classList.add("errada");
  });
  if (i === p.c) {
    pontos++;
    elFeedback.textContent = "Acertou! " + p.e;
    elFeedback.classList.add("ok");
  } else {
    elFeedback.textContent = "Não foi dessa vez. " + p.e;
    elFeedback.classList.add("erro");
  }
  elPontos.textContent = pontos + (pontos === 1 ? " ponto" : " pontos");
  btnProxima.textContent = atual === perguntas.length - 1 ? "Ver resultado" : "Próxima";
  btnProxima.hidden = false;
}

function fim() {
  elBarra.style.width = "100%";
  elProgresso.textContent = "Fim do quiz";
  elOpcoes.innerHTML = "";
  elPergunta.textContent = "Você fez " + pontos + " de " + perguntas.length + " pontos.";
  let msg = "Bora rever a carreira dele lá em cima!";
  if (pontos >= 6) msg = "Fã de verdade! Você manja muito do LaMelo.";
  else if (pontos >= 4) msg = "Mandou bem! Você conhece bem a história dele.";
  elFeedback.textContent = msg;
  elFeedback.className = "quiz_feedback ok";
  btnProxima.hidden = true;
  btnReiniciar.hidden = false;
}

btnProxima.addEventListener("click", () => {
  atual++;
  if (atual < perguntas.length) mostrar();
  else fim();
});

btnReiniciar.addEventListener("click", () => {
  atual = 0;
  pontos = 0;
  mostrar();
});

mostrar();